import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class HttpService {

  constructor(private _http: HttpClient) {
    this.getPokemon();
          }

  getPokemon() {

    let mewtwo = this._http.get('http://pokeapi.co/api/v2/pokemon/150/');
    mewtwo.subscribe(data => console.log("Got our tasks!", data));
    mewtwo.subscribe(data => console.log("Mewtwo's abilities are "+(<any>data).abilities[0].ability.name+" and " +(<any>data).abilities[1].ability.name));
    let numofpoke = this._http.get('http://pokeapi.co/api/v2/ability/unnerve');
    numofpoke.subscribe(data => console.log(((<any>data).pokemon).length + " other pokemon have the unnerve ability"))
    let numofpoke2 = this._http.get('http://pokeapi.co/api/v2/ability/pressure');
    numofpoke2.subscribe(data => console.log(((<any>data).pokemon).length + " other pokemon have the pressure ability"))


  }
};
