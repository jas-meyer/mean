import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { ShintoService } from './shinto.service';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { MineComponent } from './mine/mine.component';
import { SellComponent } from './sell/sell.component';
import { BuyComponent } from './buy/buy.component';
import { LedgerComponent } from './ledger/ledger.component';
import { TransComponent } from './trans/trans.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MineComponent,
    SellComponent,
    BuyComponent,
    LedgerComponent,
    TransComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [ShintoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
