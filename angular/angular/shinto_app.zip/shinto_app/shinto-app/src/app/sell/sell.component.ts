import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ShintoService } from '../shinto.service';
@Component({
  selector: 'app-sell',
  templateUrl: './sell.component.html',
  styleUrls: ['./sell.component.css']
})
export class SellComponent implements OnInit {
  currents: object;
  grabcurrents: object;
  sell: number;

    constructor(private _shintoService: ShintoService) { }

    ngOnInit() {
      this.getCurrents();
    }
  getCurrents(){
    this.grabcurrents= this._shintoService.Currents();
    console.log(this.grabcurrents)
  }
  Selling(){
  console.log(this.sell)
  this.grabcurrents = this._shintoService.Sell(this.sell);
  console.log(this.grabcurrents)
  }
  }
