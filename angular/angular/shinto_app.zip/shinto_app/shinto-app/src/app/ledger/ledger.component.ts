import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ShintoService } from '../shinto.service';

@Component({
  selector: 'app-ledger',
  templateUrl: './ledger.component.html',
  styleUrls: ['./ledger.component.css']
})
export class LedgerComponent implements OnInit {
trans: object;
  constructor(private _shintoService: ShintoService) {}

  ngOnInit() {
    this.grabHistory();
  }
  grabHistory(){
    this.trans= this._shintoService.History();
    console.log(this.trans)
  }
}
