import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ShintoService } from '../shinto.service';
@Component({
  selector: 'app-mine',
  templateUrl: './mine.component.html',
  styleUrls: ['./mine.component.css']
})
export class MineComponent implements OnInit {
  mine: number;
  constructor(private _shintoService: ShintoService) {

  }

  ngOnInit() {
  }

  MineCoin(){
    if (this.mine == 1888){
      let mining = this._shintoService.successfulMine()
      }

    else{
      console.log("Your answer is wrong")
    }
  }
}
