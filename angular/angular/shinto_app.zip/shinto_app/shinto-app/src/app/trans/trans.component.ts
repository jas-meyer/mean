import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ShintoService } from '../shinto.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-trans',
  templateUrl: './trans.component.html',
  styleUrls: ['./trans.component.css']
})
export class TransComponent implements OnInit {
tran: object;
id: number;
  constructor(
    private _route: ActivatedRoute,
    private _shintoService: ShintoService,
  ) {}

  ngOnInit() {
  this.oneTran();
  }
oneTran(){
  this._route.params.subscribe((params: Params) =>  this.id = params['id']);
  console.log(this.id)
  this.tran= this._shintoService.grabTran(this.id);
}
}
