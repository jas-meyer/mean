import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class ShintoService {
numofcoins = 0;
history = []
id = 1
currentValue= 1
buyBack = {}

  constructor(private _http: HttpClient) {

  }
successfulMine(){
  this.numofcoins++
  console.log("You have ", this.numofcoins," coins.")
  let trans = {id: this.id, action: "Mined", amount: 1, value: this.numofcoins}
  this.history.push(trans)
  console.log(this.history)
  this.id++
}
Currents(){
let currents ={current: this.currentValue, owned: this.numofcoins};
return currents;
}
Buy(num){
  console.log(this.numofcoins)
  console.log(num)
  this.numofcoins += num;
  console.log("You have "+ this.numofcoins+" coins.")
  let trans = {id: this.id, action: "Bought", amount: num, value: this.numofcoins}
  this.history.push(trans)
  console.log(this.history)
  this.currentValue += num
  this.id++
  let buyBack ={current: this.currentValue, owned: this.numofcoins};
  return buyBack
}
Sell(num){
  this.numofcoins -= num
  console.log("You have ", this.numofcoins," coins.")
  let trans = {id: this.id, action: "Sold", amount: num, value: this.numofcoins}
  this.history.push(trans)
  console.log(this.history)
  this.currentValue -= num
  this.id++
  let sellBack ={current: this.currentValue, owned: this.numofcoins};
  return sellBack
}
History(){
  return this.history
}
grabTran(id){
for(var i = 0; i < (this.history).length; i++){
  if(id == this.history[i].id){
    console.log("This is the trans", this.history[i])
    return this.history[i]
  }
}

}

}
