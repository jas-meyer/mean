import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ShintoService } from '../shinto.service';
@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.css']
})
export class BuyComponent implements OnInit {
currents: object;
grabcurrents: object;
buy: number;
  constructor(private _shintoService: ShintoService) { }

  ngOnInit() {
    this.getCurrents();
  }
getCurrents(){
  this.grabcurrents= this._shintoService.Currents();
  console.log(this.grabcurrents)
}
Buying(){
console.log(this.buy)
let intbuy = Math.floor(this.buy);
this.grabcurrents = this._shintoService.Buy(intbuy);
console.log(this.grabcurrents)
}
}
