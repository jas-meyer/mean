import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
product: any;
id: number;
  constructor(
  private _httpService: HttpService,
  private _route: ActivatedRoute,
  private _router: Router
  ) { }

  ngOnInit() {
  this.oneProduct();
  }

  oneProduct(){
        this._route.params.subscribe((params: Params) =>  this.id = params['id'])
        let getOne = this._httpService.editProduct(this.id);
        getOne.subscribe(data => {
        console.log("Got the product!",data)
        this.product = data;
        console.log(this.product);
        })
      }
  Delete(id){
  let remove = this._httpService.deleteProduct(id);
  remove.subscribe(data =>{
  console.log("Deleting an Quote!", data)
  // this.All()
  this._router.navigate(['']);
  });
  }
}
