import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
products: object;
  constructor(
    private _httpService: HttpService
  ) { }

  ngOnInit() {
  this.All()
  }
  All(){
      let getAll = this._httpService.getProducts();

      getAll.subscribe(data => {

        console.log("Got the products!",data)

        this.products = data;
      })
    }
    
}
