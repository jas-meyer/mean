import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service'
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
product: object;
errmessage: object;
  constructor(
  private _httpService: HttpService,
  private _router: Router

  ) { }

  ngOnInit() {
  this.product = {name: "", quantity: "", price: ""},
  this.errmessage = {name: "", quantity: "", price: ""}
  }
  Create(){
      console.log(this.product)

      let add = this._httpService.addProduct(this.product);
       add.subscribe(
         (res) => {
         console.log(res)
         this._router.navigate(['']);
       },
         (err) =>{
         console.log(err.error.errors)
         console.log("The Error is " + err.error)
        this.errmessage = err.error.errors
       }
     )};

}
