import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
id: number;
product: object;
errmessage: any;
datas: any;
  constructor(private _route: ActivatedRoute,
    private _httpService: HttpService,
  private _router: Router,

  ) {
this.product = {name: "", quantity: "", price: ""},
this.errmessage = {name: "", quantity: "", price: ""}
   }

  ngOnInit() {
  this.oneProduct();
  }
  oneProduct(){
        this._route.params.subscribe((params: Params) =>  this.id = params['id'])
        let getOne = this._httpService.editProduct(this.id);
        getOne.subscribe(data => {
        console.log("Got the product!",data)
        this.product = data;
        console.log(this.product);
        })
      }

      update(event){
            event.preventDefault()
            this._route.params.subscribe((params: Params) =>  this.id = params['id'])
            console.log(this.id)
            console.log(this.product)
            let update = this._httpService.updateProduct(this.id, this.product);
            update.subscribe((data) => {
            this.datas = data
            console.log(this.datas)
            // this._router.navigate(['']);
          },
          (err) =>{
            console.log(err.error.errors)
            console.log("The Error is " + err.error)
           this.errmessage = err.error.errors
          }

           )}


}
