
import { HttpService } from './http.service';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  total: number = 0;
  str: any = [];
  constructor(private _httpService: HttpService){}

  ngOnInit(){
  }

  Farm() {
      let result = Math.floor(Math.random()*11)+10
      this.total += result
      this.str.push("You have won "+ result +" gold from a farm. Really.");
      return this.str;
  }

  Cave() {

    let result = Math.floor(Math.random()*6)+5
    this.total += result
    this.str.push("You have won "+ result +" gold from a cave. Really!")
    return this.str
  }

  House() {
    let result = Math.floor(Math.random()*4)+2
    this.total += result
    this.str.push("You have won "+ result +" gold from a House. You are a thief!")
    return this.str
  }

  Casino() {
    let result = Math.floor(Math.random()*101)-50
    this.total += result
    this.str.push("You have won/lost "+ result +" gold from a Casino.")
    return this.str
  }
}
