import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthorService } from '../author.service';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
id: string;
author: object;
editAuthor: object;
  constructor(
    private _route: ActivatedRoute,
    private _httpService: AuthorService,) { }

  ngOnInit() {
  this.oneAuthor()
  this.author = {name: ""}
  }
  oneAuthor(){
    this._route.params.subscribe((params: Params) =>  this.id = params['id'])
    let getOne = this._httpService.editAuthor(this.id);
    getOne.subscribe(data => {
    console.log("Got the author!",data)
    this.author = data;
    console.log(this.author);
    })
  }
  update(event){
    event.preventDefault()
    this._route.params.subscribe((params: Params) =>  this.id = params['id'])
    let update = this._httpService.updateAuthor(this.id, this.author);
    update.subscribe(data => {
    console.log("Updating Authors", data)

       });

  }
  // oneAuthor(){
  //   this._route.params.subscribe((params: Params) =>  this.id = params['id']);
  //   console.log(this.id)
  //   this.author= this._httpService.getAuthors();
  // }
}
