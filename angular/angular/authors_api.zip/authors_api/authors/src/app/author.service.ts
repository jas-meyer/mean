import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Injectable()
export class AuthorService {
id: string;
constructor(private _http: HttpClient) {

}
getAuthors(){

  return this._http.get('/authors');
}
deleteAuthor(id){
  console.log("id: ",id)
  return this._http.delete('/authors/'+id)

}
editAuthor(id){
  console.log(id)
  return this._http.get('/authors/'+id);
}
addAuthor(newAuthor){
  return this._http.post('/authors', newAuthor)
}
updateAuthor(id, update){
  return this._http.put('/authors/'+id,update)
}
}
