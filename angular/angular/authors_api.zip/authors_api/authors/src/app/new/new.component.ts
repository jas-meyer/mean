import { Component, OnInit } from '@angular/core';
import { AuthorService } from '../author.service'
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
author: object
  constructor(
    private _router: Router,
    private _httpService: AuthorService
          ) {
  this.author = {name: " "};
  }

  ngOnInit() {
  }
Create(){
  console.log(this.author)
  let add = this._httpService.addAuthor(this.author);
   add.subscribe(data => {
    console.log("Adding an authors!",data)
     this._router.navigate(['']);
});
}
}
