import { Component, OnInit } from '@angular/core';
import { AuthorService } from '../author.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
authors: object;
  constructor(
    private _router: Router,
    private _httpService: AuthorService) { }

  ngOnInit() {
    this.All()
  }
All(){
  let getAll = this._httpService.getAuthors();
  getAll.subscribe(data => {
    console.log("Got the authors!",data)
    this.authors = data;
  })
}
Delete(id){

  let deleteOne = this._httpService.deleteAuthor(id);
  deleteOne.subscribe(data =>{
    console.log("Deleting an author!", data)
    this.All()
})

}
}
