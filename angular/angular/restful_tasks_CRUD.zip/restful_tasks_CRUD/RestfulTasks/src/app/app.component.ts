import { HttpService } from './http.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  newTask: any;
  Task: any;
  editTask: any;
  ones: any;
  onetitle: string;
  onedescription: string;
  constructor(private _httpService: HttpService){}
  ngOnInit(){
  this.All();
  this.newTask = {title:"", description: ""}
  this.editTask = {title:"", description: ""}

  }
  tasks: any;
  //newTask: any;
    All(){
       let observable = this._httpService.getTasks();
       observable.subscribe(data => {
          console.log("Got our tasks!", data)
          // In this example, the array of tasks is assigned to the key 'tasks' in the data object.
          // This may be different for you, depending on how you set up your Task API.
          this.tasks = data;
       });
    }
 onSubmit(){
    console.log(this.newTask)
     let create = this._httpService.addTask(this.newTask);
     create.subscribe(data => {
       console.log("Adding task", data)
     });
     this.newTask ={ title: "", description: ""};
   }
   editSubmit(id){
      console.log(this.editTask)
       let update = this._httpService.updateTask(id, this.editTask);
       update.subscribe(data => {
         console.log("Updating task", data)
       });
       this.editTask ={ title: "", description: ""};
     }
    // }

Destroy(removeTask){
console.log(removeTask);
let destroy = this._httpService.removeTask(removeTask)
destroy.subscribe(data => {
console.log("Deleting task", data)
})
  }
One(editid){
let one = this._httpService.grabTask(editid)
one.subscribe(data => {
console.log("Grabbing Task", data)
  this.onetitle= data[0].title;
   console.log(this.onetitle)

 console.log(this.ones)
this.ones = data;
this.onetitle= data[0].title;
this.onedescription =  data[0].description;
})
}

}
