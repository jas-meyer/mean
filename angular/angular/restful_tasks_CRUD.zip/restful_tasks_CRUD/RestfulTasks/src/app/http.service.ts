import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class HttpService {
  newtask: any;
  id: any;
  update: any;
  constructor(private _http: HttpClient) {
    this.getTasks();
    this.addTask(this.newtask);
    this.removeTask(this.id)
    this.updateTask(this.id, this.update)
          }
  getTasks() {
    // let tempObservable = this._http.get('/tasks');
    // tempObservable.subscribe(data => console.log("Got our tasks!", data));
    return this._http.get('/tasks');
  }
  addTask(newtask) {

    return this._http.post('/tasks', newtask)
  }
  removeTask(id){
    console.log(id)
    return this._http.delete('/tasks/'+ id)
  }
  grabTask(id){
    console.log(id)
    return this._http.get('/tasks/'+id)
  }
  updateTask(id, update){
    return this._http.put('/tasks/'+id, update)
  }
}
