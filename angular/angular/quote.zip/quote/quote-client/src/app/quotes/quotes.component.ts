import { Component, OnInit } from '@angular/core';
import { QuoteService } from '../quote.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-quotes',
  templateUrl: './quotes.component.html',
  styleUrls: ['./quotes.component.css']
})
export class QuotesComponent implements OnInit {
quotes: object;
id: string;
author: string;
datas: any;
  constructor(private _httpService: QuoteService,
    private _router: Router,
    private _route: ActivatedRoute,
  ) { }

  ngOnInit() {
  this.All();
  this.oneAuthor();
  }
  All(){
      this._route.params.subscribe((params: Params) =>  this.id = params['id'])
      let getAll = this._httpService.getQuotes(this.id);
      getAll.subscribe(data => {

        console.log("Got the Quotes!",data)

        this.quotes = data;
      })
    }
  voteUp(id){
    let voteup = this._httpService.VoteUp(id);
    voteup.subscribe(data =>{
    console.log("Vote Up!", data)
    this.All()

  });
}
  voteDown(id){
    let votedown = this._httpService.VoteDown(id);
    votedown.subscribe(data =>{
    console.log("Vote Up!", data)
    this.All()

  });

  }
  Delete(id){
    let remove = this._httpService.deleteQuote(id);
    remove.subscribe(data =>{
    console.log("Deleting an Quote!", data)
    this.All()

  });
}
  Redirect(id){

    this._router.navigate(['write', id]);
  }
  oneAuthor(){
        this._route.params.subscribe((params: Params) =>  this.id = params['id'])
        let getOne = this._httpService.editAuthor(this.id);
        getOne.subscribe(data => {
        console.log("Got the author!",data)
        this.datas = data
        this.author = this.datas.name;
        console.log(this.author);
        })
      }


}
