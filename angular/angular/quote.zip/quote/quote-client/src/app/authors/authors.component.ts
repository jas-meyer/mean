import { Component, OnInit } from '@angular/core';
import { QuoteService } from '../quote.service';
@Component({
  selector: 'app-authors',
  templateUrl: './authors.component.html',
  styleUrls: ['./authors.component.css']
})
export class AuthorsComponent implements OnInit {
authors: object;
  constructor(
    private _httpService: QuoteService,
  ) { }

  ngOnInit() {
    this.All()
  }
  All(){
      let getAll = this._httpService.getAuthors();

      getAll.subscribe(data => {

        console.log("Got the authors!",data)

        this.authors = data;
      })
    }
  
}
