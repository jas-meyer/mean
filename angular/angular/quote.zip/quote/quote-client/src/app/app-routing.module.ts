import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AuthorsComponent } from './authors/authors.component';
import { QuotesComponent } from './quotes/quotes.component';
import { NewAuthorComponent } from './new-author/new-author.component';
import { NewQuoteComponent } from './new-quote/new-quote.component';
import { EditAuthorComponent } from './edit-author/edit-author.component';
const routes: Routes = [
  {path: '', component: AuthorsComponent},
  {path: 'new', component: NewAuthorComponent},
  {path: 'quotes/:id', component: QuotesComponent},
  {path: 'write/:id', component: NewQuoteComponent},
  {path: 'edit/:id', component: EditAuthorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
