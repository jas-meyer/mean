import { Component, OnInit } from '@angular/core';
import { QuoteService } from '../quote.service'
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-new-author',
  templateUrl: './new-author.component.html',
  styleUrls: ['./new-author.component.css']
})
export class NewAuthorComponent implements OnInit {
  author: object;
  errmessage: string;
  datas: any;
  constructor(private _router: Router,
  private _httpService: QuoteService
) {
this.author= {name: ""}
}

  ngOnInit() {
  }
  Create(){
    console.log(this.author)

    let add = this._httpService.addAuthor(this.author);
     add.subscribe(data => {
       this.datas = data
       console.log(this.datas)
      if (this.datas.message == "Error") {
        console.log(this.datas);
        this.errmessage = this.datas.err.message

      }
      else{
      console.log("Adding a author!",data)
      this.author= {name: ""}
      this._router.navigate(['']);
     }
  });
  }
}
