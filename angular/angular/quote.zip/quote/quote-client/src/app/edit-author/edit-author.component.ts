import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { QuoteService } from '../quote.service';
@Component({
  selector: 'app-edit-author',
  templateUrl: './edit-author.component.html',
  styleUrls: ['./edit-author.component.css']
})
export class EditAuthorComponent implements OnInit {
  id: string;
  author: object;
  datas: any;
  errmessage: any;
  constructor(private _route: ActivatedRoute,
    private _httpService: QuoteService,
  private _router: Router,) {
    this.author = {name: ""}
  }

  ngOnInit() {
      this.oneAuthor()
  }
  oneAuthor(){
        this._route.params.subscribe((params: Params) =>  this.id = params['id'])
        let getOne = this._httpService.editAuthor(this.id);
        getOne.subscribe(data => {
        console.log("Got the author!",data)
        this.author = data;
        console.log(this.author);
        })
      }
      update(event){
        event.preventDefault()
        this._route.params.subscribe((params: Params) =>  this.id = params['id'])
        console.log(this.id)
        console.log(this.author)
        let update = this._httpService.updateAuthor(this.id, this.author);
        update.subscribe(data => {
        this.datas = data
        console.log(this.datas)
          if ((this.datas).message == "Error") {
            console.log(this.datas);
            this.errmessage = (this.datas).err.message
          }
          else{
          console.log("Updating the author", this.datas)
          this.author= {title: "", price: "", img: ""}
          this._router.navigate(['']);
         }
           });
  }
}
