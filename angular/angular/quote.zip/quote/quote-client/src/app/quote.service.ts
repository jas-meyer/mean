import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class QuoteService {

  constructor(private _http: HttpClient) { }
  getAuthors(){
      return this._http.get('/author');
    }
  deleteAuthor(id){
    console.log("id: ",id)
    return this._http.delete('/author/'+id)
  }
  editAuthor(id){
      console.log(id)
      return this._http.get('/author/'+id);
    }
  addAuthor(newAuthor){
    return this._http.post('/author', newAuthor)
  }
  updateAuthor(id, update){
    return this._http.put('/author/'+id,update)
  }
  getQuotes(id){
    return this._http.get('/quote/'+id)
  }
  addQuote(id, newQuote){
    return this._http.post('/author/'+id, newQuote)
  }
  VoteUp(id){
    return this._http.get('quote/plus/'+id)
  }
  VoteDown(id){
    return this._http.get('quote/minus/'+id)
  }
  deleteQuote(id){
    return this._http.delete('quote/'+id)
  }



}
