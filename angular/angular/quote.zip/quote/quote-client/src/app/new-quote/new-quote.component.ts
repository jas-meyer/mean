import { Component, OnInit } from '@angular/core';
import { QuoteService } from '../quote.service'
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-new-quote',
  templateUrl: './new-quote.component.html',
  styleUrls: ['./new-quote.component.css']
})
export class NewQuoteComponent implements OnInit {
  quote: object;
  errmessage: string;
  datas: any;
  id: string;
  author: object;
  constructor(
    private _router: Router,
    private _httpService: QuoteService,
    private _route: ActivatedRoute,
  ) {
this.quote= {content: ""}
   }

  ngOnInit() {
  this.oneAuthor();
  }
  Create(){
    console.log(this.quote)
    this._route.params.subscribe((params: Params) =>  this.id = params['id'])
    let add = this._httpService.addQuote(this.id,this.quote);
     add.subscribe(data => {
       this.datas = data
      if (this.datas.message == "Error") {
        console.log(this.datas);
        this.errmessage = this.datas.err.message

      }
      else{
      console.log("Adding a quote!",data)
      this.quote= {content: ""}
      this._router.navigate(['']);
     }
  });
}
  oneAuthor(){
        this._route.params.subscribe((params: Params) =>  this.id = params['id'])
        let getOne = this._httpService.editAuthor(this.id);
        getOne.subscribe(data => {
        this.datas = data
        console.log("Got the author!",data)
        this.author = this.datas.name;
        console.log(this.author);
        })
      }
}
