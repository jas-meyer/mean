import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-burbank',
  templateUrl: './burbank.component.html',
  styleUrls: ['./burbank.component.css']
})
export class BurbankComponent implements OnInit {
  weather: any;
  main: any;
    constructor(private _httpService: HttpService) { }

    ngOnInit() {
    this.Weather(this.weather)
    }
   Weather(city) {
   let grabweather = this._httpService.getWeather("burbank");
   grabweather.subscribe(data => {

   this.weather = <any>data
  })
   }
  }
