import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-chicago',
  templateUrl: './chicago.component.html',
  styleUrls: ['./chicago.component.css']
})
export class ChicagoComponent implements OnInit {
  weather: any;
  main: any;
    constructor(private _httpService: HttpService) { }

    ngOnInit() {
    this.Weather(this.weather)
    }
   Weather(city) {
   let grabweather = this._httpService.getWeather("chicago");
   grabweather.subscribe(data => {

   this.weather = <any>data
  })
   }
  }
