import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-dc',
  templateUrl: './dc.component.html',
  styleUrls: ['./dc.component.css']
})
export class DcComponent implements OnInit {
  weather: any;
  main: any;
    constructor(private _httpService: HttpService) { }

    ngOnInit() {
    this.Weather(this.weather)
    }
   Weather(city) {
   let grabweather = this._httpService.getWeather("washington");
   grabweather.subscribe(data => {
  
   this.weather = <any>data
  })
   }
  }
