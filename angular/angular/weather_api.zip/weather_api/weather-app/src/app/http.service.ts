import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class HttpService {
  weather: any
  constructor(private _http: HttpClient) {
  this.getWeather(this.weather);
}

getWeather(city) {

  console.log(city)

  return this._http.get("https://api.openweathermap.org/data/2.5/weather?q="+city+",us&units=imperial&APPID=616bbe9129e94af7f41e939cc86298e3")
}
}
