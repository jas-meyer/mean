import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-dallas',
  templateUrl: './dallas.component.html',
  styleUrls: ['./dallas.component.css']
})

export class DallasComponent implements OnInit {
weather: any;
main: any;
city: string;
  constructor(private _httpService: HttpService) { }

  ngOnInit() {
  this.Weather(this.city)
  }
 Weather(city) {
 let grabweather = this._httpService.getWeather("dallas");
 grabweather.subscribe(data => {

 this.weather = <any>data
})
 }
}
