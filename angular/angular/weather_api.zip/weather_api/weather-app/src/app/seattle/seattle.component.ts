import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
@Component({
  selector: 'app-seattle',
  templateUrl: './seattle.component.html',
  styleUrls: ['./seattle.component.css']
})
export class SeattleComponent implements OnInit {
    weather: any;

      constructor(private _httpService: HttpService) { }

      ngOnInit() {
      this.Weather(this.weather)
      }
     Weather(city) {
     let grabweather = this._httpService.getWeather("seattle");
     grabweather.subscribe(data => {
     this.weather = <any>data
    })
     }
    }
